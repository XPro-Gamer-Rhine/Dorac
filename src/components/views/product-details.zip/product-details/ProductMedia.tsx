function ProductMedia() {
	return (
		<div className="col-lg-7 col-md-12 col-sm-12">
			<div className="product-tab-wrapper rbt-sticky-top-adjust">
				<div className="pd-tab-inner">
					<div
						className="nav rn-pd-nav rn-pd-rt-content nav-pills"
						id="v-pills-tab"
						role="tablist"
						aria-orientation="vertical"
					>
						<button
							className="nav-link active"
							id="v-pills-home-tab"
							data-bs-toggle="pill"
							data-bs-target="#v-pills-home"
							type="button"
							role="tab"
							aria-controls="v-pills-home"
							aria-selected="true"
						>
							<span className="rn-pd-sm-thumbnail">
								<img src="assets/images/portfolio/sm/portfolio-01.jpg" alt="Nft_Profile" />
							</span>
						</button>
						<button
							className="nav-link"
							id="v-pills-profile-tab"
							data-bs-toggle="pill"
							data-bs-target="#v-pills-profile"
							type="button"
							role="tab"
							aria-controls="v-pills-profile"
							aria-selected="false"
						>
							<span className="rn-pd-sm-thumbnail">
								<img src="assets/images/portfolio/sm/portfolio-02.jpg" alt="Nft_Profile" />
							</span>
						</button>
						<button
							className="nav-link"
							id="v-pills-messages-tab"
							data-bs-toggle="pill"
							data-bs-target="#v-pills-messages"
							type="button"
							role="tab"
							aria-controls="v-pills-messages"
							aria-selected="false"
						>
							<span className="rn-pd-sm-thumbnail">
								<img src="assets/images/portfolio/sm/portfolio-03.jpg" alt="Nft_Profile" />
							</span>
						</button>
					</div>
					<div className="tab-content rn-pd-content" id="v-pills-tabContent">
						<div
							className="tab-pane fade show active"
							id="v-pills-home"
							role="tabpanel"
							aria-labelledby="v-pills-home-tab"
						>
							<div className="rn-pd-thumbnail">
								<img src="assets/images/portfolio/lg/portfolio-01.jpg" alt="Nft_Profile" />
							</div>
						</div>
						<div className="tab-pane fade" id="v-pills-profile" role="tabpanel" aria-labelledby="v-pills-profile-tab">
							<div className="rn-pd-thumbnail">
								<img src="assets/images/portfolio/lg/portfolio-02.jpg" alt="Nft_Profile" />
							</div>
						</div>
						<div
							className="tab-pane fade"
							id="v-pills-messages"
							role="tabpanel"
							aria-labelledby="v-pills-messages-tab"
						>
							<div className="rn-pd-thumbnail">
								<img src="assets/images/portfolio/lg/portfolio-03.jpg" alt="Nft_Profile" />
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	)
}

export default ProductMedia

import Bereadcrumb from '../../layout/Bereadcrumb'
import useCDN from '../../../hooks/useCDN'
import DataContent from './DataContent'
import ProductMedia from './ProductMedia'
import TabPanel from './TabPanel'
import ActionDateTime from './ActionDateTiem'
import ItemsPreview from './ItemsPreview'

const bereadcrumb = [
	{
		id: 7657,
		url: '/',
		name: 'Home',
	},
	{
		id: 56345,
		url: '/',
		name: 'Product Details',
	},
]

function ProductDetails() {
	useCDN()

	return (
		<>
			<Bereadcrumb title="Product Details" pages={bereadcrumb} />
			<div className="product-details-area rn-section-gapTop">
				<div className="container">
					<div className="row g-5">
						<ProductMedia />
						<div className="col-lg-5 col-md-12 col-sm-12 mt_md--50 mt_sm--60">
							<div className="rn-pd-content-area">
								<DataContent />
								<div className="row">
									<div className="col-6">
										<a className="btn btn-primary-alta mt--30 w-100" href="#">
											BUY/SELL
										</a>
									</div>
									<div className="col-6">
										<a className="btn btn-primary-alta mt--30 w-100" href="#">
											TRANSFARE
										</a>
									</div>
								</div>
								<div className="rn-bid-details">
									<TabPanel />
									<ActionDateTime />
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>

			<ItemsPreview title="Recent View" />
			<ItemsPreview title="Related Item" />
		</>
	)
}

export default ProductDetails
